import React from "react";

const KambazApp: React.FC = () => {
  return (
    <div style={{ textAlign: "center", padding: "20px" }}>
      <h1>Kambaz Application</h1>
      <p>Welcome to the Kambaz application!</p>
      <a href="/" style={{ textDecoration: "none", marginTop: "20px" }}>
        Landing Page
      </a>
    </div>
  );
};

export default KambazApp;
